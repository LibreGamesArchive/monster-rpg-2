function get_actions()
	return "Attack", "Item", "Defend", "Run", ""
end

