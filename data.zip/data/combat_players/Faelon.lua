function get_actions()
	return "Attack", "Magic", "Item", "Defend", "Run"
end

