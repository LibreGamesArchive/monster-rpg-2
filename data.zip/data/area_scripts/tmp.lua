function start()
	descriptifyPlayer()
end

function stop()
end

function update(step)
end

function activate(activator, activated)
end

function collide(id1, id2)
end

